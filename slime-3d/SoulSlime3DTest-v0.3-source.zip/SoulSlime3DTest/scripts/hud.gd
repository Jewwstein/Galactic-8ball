extends Control

var joystick_origin := Vector2.ZERO
var joystick_current := Vector2.ZERO
var joystick_active := false
var essence := 0
var morph := 0
var enemy_hp := 3
var enemy_dead := false
var message := "Explore the cave. Collect crystals."
var message_until := 0

func _ready():
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)

func set_joystick(origin: Vector2, current: Vector2, active: bool):
	joystick_origin = origin
	joystick_current = current
	joystick_active = active
	queue_redraw()

func flash(text: String, ms := 1800):
	message = text
	message_until = Time.get_ticks_msec() + ms
	queue_redraw()

func _process(_delta):
	queue_redraw()

func _draw():
	var size = get_viewport_rect().size
	# top HUD
	draw_rect(Rect2(18, 16, 400, 90), Color(0.02,0.04,0.07,0.78), true)
	draw_string(ThemeDB.fallback_font, Vector2(34, 45), "SOUL SLIME — 3D CAVE TEST", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
	draw_string(ThemeDB.fallback_font, Vector2(34, 73), "ESSENCE %d    MORPH %d%%" % [essence, morph], HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(0.45,0.95,1.0))
	var enemy_text = "BAT: DEFEATED — ABSORB READY" if enemy_dead else "BAT HP: %d/3" % enemy_hp
	draw_string(ThemeDB.fallback_font, Vector2(34, 97), enemy_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1.0,0.72,0.55))

	# objective/message
	var msg = message
	if message_until > 0 and Time.get_ticks_msec() > message_until:
		msg = "Move with the left thumb. Drag the right side to look."
	draw_rect(Rect2(size.x*0.5-310, 20, 620, 48), Color(0.01,0.02,0.04,0.62), true)
	draw_string(ThemeDB.fallback_font, Vector2(size.x*0.5-290, 51), msg, HORIZONTAL_ALIGNMENT_CENTER, 580, 18, Color.WHITE)

	# joystick
	var o = joystick_origin if joystick_active else Vector2(150, size.y-155)
	var c = joystick_current if joystick_active else o
	draw_circle(o, 78, Color(0.08,0.16,0.22,0.35))
	draw_circle(o, 78, Color(0.3,0.85,1.0,0.55), false, 4)
	draw_circle(c, 32, Color(0.25,0.9,1.0,0.72))

	# control hints
	draw_string(ThemeDB.fallback_font, Vector2(size.x-470, size.y-35), "ATTACK     DODGE     ABSORB", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color(0.85,0.95,1))
