extends Node3D

const SPEED := 4.8
const DODGE_SPEED := 9.5
const GRAVITY := 18.0
const JOY_RADIUS := 85.0

var player: CharacterBody3D
var player_visual: Node3D
var camera_pivot: Node3D
var spring: SpringArm3D
var camera: Camera3D
var hud: Control
var attack_button: Button
var dodge_button: Button
var absorb_button: Button
var left_finger := -1
var look_finger := -1
var joy_origin := Vector2.ZERO
var joy_now := Vector2.ZERO
var joy_vector := Vector2.ZERO
var yaw := 0.0
var pitch := -0.22
var dodge_timer := 0.0
var bat: Node3D
var bat_hp := 3
var bat_dead := false
var bat_base := Vector3.ZERO
var crystals: Array[Area3D] = []
var essence := 0
var morph := 0

func _ready():
	build_world()
	build_player()
	build_enemy()
	build_crystals()
	build_ui()

func build_world():
	var env_node = WorldEnvironment.new()
	var env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.008, 0.013, 0.025)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.18,0.25,0.38)
	env.ambient_light_energy = 0.55
	env.fog_enabled = true
	env.fog_light_color = Color(0.09,0.18,0.26)
	env.fog_density = 0.018
	env.glow_enabled = true
	env_node.environment = env
	add_child(env_node)

	var moon = DirectionalLight3D.new()
	moon.light_color = Color(0.48,0.68,1.0)
	moon.light_energy = 0.85
	moon.rotation_degrees = Vector3(-55,-28,0)
	moon.shadow_enabled = true
	add_child(moon)

	# dark fallback floor beneath the imported cave pieces
	var floor = StaticBody3D.new()
	var mesh = MeshInstance3D.new()
	var plane = PlaneMesh.new()
	plane.size = Vector2(42,42)
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.045,0.055,0.07)
	mat.roughness = 0.95
	plane.material = mat
	mesh.mesh = plane
	floor.add_child(mesh)
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(42,0.2,42)
	shape.shape = box
	shape.position.y = -0.12
	floor.add_child(shape)
	add_child(floor)

	# cave visuals found from Kenney's CC0 modular cave kit
	spawn_cave_piece("res://assets/cave/room-large.glb", Vector3(0,0,0), 0)
	spawn_cave_piece("res://assets/cave/corridor-wide.glb", Vector3(0,0,-8), 0)
	spawn_cave_piece("res://assets/cave/corridor-wide.glb", Vector3(0,0,-15), 0)
	spawn_cave_piece("res://assets/cave/room-small.glb", Vector3(0,0,-23), 0)
	spawn_cave_piece("res://assets/cave/corridor-corner.glb", Vector3(7,0,-23), 90)

	# simple invisible boundaries make the test playable even before per-mesh collision pass
	for spec in [
		[Vector3(-8,2,-10), Vector3(1,4,34)], [Vector3(8,2,-10), Vector3(1,4,34)],
		[Vector3(0,2,7), Vector3(17,4,1)], [Vector3(0,2,-29), Vector3(17,4,1)]
	]:
		var wall = StaticBody3D.new()
		var cs = CollisionShape3D.new()
		var bs = BoxShape3D.new()
		bs.size = spec[1]
		cs.shape = bs
		wall.position = spec[0]
		wall.add_child(cs)
		add_child(wall)

func spawn_cave_piece(path: String, pos: Vector3, rot_y_deg: float):
	var packed = load(path)
	if packed is PackedScene:
		var inst = packed.instantiate()
		inst.position = pos
		inst.rotation_degrees.y = rot_y_deg
		add_child(inst)

func build_player():
	player = CharacterBody3D.new()
	player.name = "PlayerSlime"
	player.position = Vector3(0,0.65,3.0)
	add_child(player)
	var collider = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.48
	capsule.height = 1.0
	collider.shape = capsule
	player.add_child(collider)

	var found = load("res://assets/characters/Slime.glb")
	if found is PackedScene:
		player_visual = found.instantiate()
		player_visual.scale = Vector3(1.15,1.0,1.15)
		player.add_child(player_visual)
		auto_play_animation(player_visual)
	else:
		player_visual = MeshInstance3D.new()
		var sphere = SphereMesh.new()
		sphere.height = 1.05
		sphere.radius = 0.58
		var sm = StandardMaterial3D.new()
		sm.albedo_color = Color(0.15,0.68,1.0,0.72)
		sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		sphere.material = sm
		player_visual.mesh = sphere
		player.add_child(player_visual)

	# magical inner core for depth/glow
	var core = MeshInstance3D.new()
	var core_mesh = SphereMesh.new()
	core_mesh.radius = 0.19
	core_mesh.height = 0.36
	var core_mat = StandardMaterial3D.new()
	core_mat.albedo_color = Color(0.35,0.9,1.0)
	core_mat.emission_enabled = true
	core_mat.emission = Color(0.08,0.7,1.0)
	core_mat.emission_energy_multiplier = 3.4
	core_mesh.material = core_mat
	core.mesh = core_mesh
	core.position.y = 0.03
	player.add_child(core)

	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0,1.25,0)
	player.add_child(camera_pivot)
	spring = SpringArm3D.new()
	spring.spring_length = 5.0
	spring.margin = 0.18
	camera_pivot.add_child(spring)
	camera = Camera3D.new()
	camera.current = true
	camera.fov = 68
	spring.add_child(camera)

func build_enemy():
	var found = load("res://assets/characters/Bat.glb")
	bat = Node3D.new()
	bat.position = Vector3(0,2.15,-13.0)
	bat_base = bat.position
	add_child(bat)
	if found is PackedScene:
		var vis = found.instantiate()
		vis.scale = Vector3(1.25,1.25,1.25)
		bat.add_child(vis)
		auto_play_animation(vis)
	else:
		var m = MeshInstance3D.new()
		var s = SphereMesh.new()
		s.radius = 0.45
		m.mesh = s
		bat.add_child(m)

func auto_play_animation(node: Node):
	if node is AnimationPlayer:
		var names = node.get_animation_list()
		for name in names:
			if str(name).to_lower() != "reset":
				node.play(name)
				return
	for child in node.get_children():
		auto_play_animation(child)

func build_crystals():
	var positions = [Vector3(-2.6,0.9,-3.2),Vector3(2.2,0.9,-6.8),Vector3(-2.0,0.9,-10.5),Vector3(2.5,0.9,-18.0),Vector3(-2.8,0.9,-24.0)]
	for i in positions.size():
		var area = Area3D.new()
		area.position = positions[i]
		var cluster = Node3D.new()
		area.add_child(cluster)
		for j in 3:
			var mi = MeshInstance3D.new()
			var cm = CylinderMesh.new()
			cm.top_radius = 0.0
			cm.bottom_radius = 0.22 + 0.06*j
			cm.height = 1.1 + 0.35*j
			var mat = StandardMaterial3D.new()
			var col = Color(0.12 + 0.1*j, 0.65, 1.0) if i % 2 == 0 else Color(0.6,0.18+0.12*j,1.0)
			mat.albedo_color = col
			mat.emission_enabled = true
			mat.emission = col
			mat.emission_energy_multiplier = 3.2
			cm.material = mat
			mi.mesh = cm
			mi.position = Vector3((j-1)*0.28, 0.15*j, 0.06*j)
			mi.rotation_degrees.z = (j-1)*13
			cluster.add_child(mi)
		var light = OmniLight3D.new()
		light.omni_range = 4.2
		light.light_energy = 1.8
		light.light_color = Color(0.2,0.65,1.0) if i%2==0 else Color(0.65,0.25,1.0)
		area.add_child(light)
		var cs = CollisionShape3D.new()
		var ss = SphereShape3D.new()
		ss.radius = 0.8
		cs.shape = ss
		area.add_child(cs)
		add_child(area)
		crystals.append(area)

func build_ui():
	var canvas = CanvasLayer.new()
	add_child(canvas)
	var hud_script = load("res://scripts/hud.gd")
	hud = Control.new()
	hud.set_script(hud_script)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	canvas.add_child(hud)

	attack_button = make_button("ATTACK", Color(0.78,0.17,0.2,0.82), Vector2(-340,-150))
	dodge_button = make_button("DODGE", Color(0.16,0.48,0.9,0.82), Vector2(-215,-235))
	absorb_button = make_button("ABSORB", Color(0.48,0.18,0.82,0.82), Vector2(-110,-135))
	attack_button.pressed.connect(do_attack)
	dodge_button.pressed.connect(do_dodge)
	absorb_button.pressed.connect(do_absorb)

func make_button(label: String, color: Color, offset: Vector2) -> Button:
	var b = Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(115,70)
	b.anchor_left = 1.0
	b.anchor_top = 1.0
	b.anchor_right = 1.0
	b.anchor_bottom = 1.0
	b.offset_left = offset.x
	b.offset_top = offset.y
	b.offset_right = offset.x + 115
	b.offset_bottom = offset.y + 70
	b.add_theme_font_size_override("font_size", 17)
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 28
	style.corner_radius_top_right = 28
	style.corner_radius_bottom_left = 28
	style.corner_radius_bottom_right = 28
	style.border_width_left = 2; style.border_width_top = 2; style.border_width_right = 2; style.border_width_bottom = 2
	style.border_color = Color(0.7,0.9,1,0.8)
	b.add_theme_stylebox_override("normal", style)
	b.add_theme_stylebox_override("pressed", style)
	hud.add_child(b)
	return b

func _physics_process(delta):
	if not player: return
	if not player.is_on_floor():
		player.velocity.y -= GRAVITY * delta
	else:
		player.velocity.y = -0.1

	var input_vec = joy_vector
	if input_vec.length() < 0.05:
		input_vec = Input.get_vector("move_left","move_right","move_forward","move_back")
	var basis = Basis(Vector3.UP, yaw)
	var dir = (basis * Vector3(input_vec.x,0,input_vec.y)).normalized()
	var spd = DODGE_SPEED if dodge_timer > 0 else SPEED
	if dodge_timer > 0: dodge_timer -= delta
	player.velocity.x = dir.x * spd
	player.velocity.z = dir.z * spd
	if dir.length() > 0.1:
		var target_y = atan2(dir.x, dir.z)
		player.rotation.y = lerp_angle(player.rotation.y, target_y, delta*8.0)
		# squash/stretch movement juice
		var pulse = sin(Time.get_ticks_msec()*0.018) * 0.07
		player_visual.scale.y = 1.0 + pulse
		player_visual.scale.x = 1.15 - pulse*0.45
		player_visual.scale.z = 1.15 - pulse*0.45
	else:
		player_visual.scale = player_visual.scale.lerp(Vector3(1.15,1.0,1.15), delta*6.0)
	player.move_and_slide()

	camera_pivot.rotation.y = yaw - player.rotation.y
	spring.rotation.x = pitch

	# animate bat hover
	if bat and not bat_dead:
		var t = Time.get_ticks_msec()/1000.0
		bat.position = bat_base + Vector3(sin(t*1.5)*1.1, sin(t*3.0)*0.35, cos(t*1.2)*0.4)
		bat.look_at(Vector3(player.global_position.x, bat.global_position.y, player.global_position.z), Vector3.UP)

	# collect crystals by proximity
	for c in crystals.duplicate():
		if is_instance_valid(c) and player.global_position.distance_to(c.global_position) < 1.25:
			essence += 10
			hud.essence = essence
			hud.flash("Analysis complete: Mana Crystal absorbed. +10 Essence")
			crystals.erase(c)
			c.queue_free()

func do_attack():
	if bat_dead:
		hud.flash("Target defeated. Use ABSORB.")
		return
	var dist = player.global_position.distance_to(bat.global_position)
	if dist > 3.0:
		hud.flash("No target in range.")
		return
	bat_hp -= 1
	hud.enemy_hp = bat_hp
	# attack squash
	player_visual.scale = Vector3(1.35,0.72,1.35)
	if bat_hp <= 0:
		bat_dead = true
		hud.enemy_dead = true
		bat.scale = Vector3(1.0,0.35,1.0)
		bat.rotation_degrees.x = 80
		hud.flash("Cave Bat defeated. Trait detected: Echo Sense.", 2600)
	else:
		hud.flash("Body Slam! Cave Bat HP %d/3" % bat_hp)

func do_dodge():
	dodge_timer = 0.24
	hud.flash("Slime Dash")

func do_absorb():
	if not bat_dead:
		hud.flash("ABSORB requires a defeated target.")
		return
	if not is_instance_valid(bat): return
	if player.global_position.distance_to(bat.global_position) > 3.2:
		hud.flash("Move closer to the defeated creature.")
		return
	bat.queue_free()
	bat = null
	essence += 35
	morph += 20
	hud.essence = essence
	hud.morph = morph
	hud.flash("Analysis complete — ECHO SENSE acquired. Morph Data +20%", 3200)

func _input(event):
	var size = get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < size.x*0.45 and event.position.y > size.y*0.35 and left_finger == -1:
				left_finger = event.index
				joy_origin = event.position
				joy_now = event.position
				joy_vector = Vector2.ZERO
				hud.set_joystick(joy_origin, joy_now, true)
			elif event.position.x > size.x*0.45 and event.position.y < size.y-250 and look_finger == -1:
				look_finger = event.index
		else:
			if event.index == left_finger:
				left_finger = -1
				joy_vector = Vector2.ZERO
				hud.set_joystick(Vector2.ZERO, Vector2.ZERO, false)
			elif event.index == look_finger:
				look_finger = -1
	elif event is InputEventScreenDrag:
		if event.index == left_finger:
			var d = event.position - joy_origin
			if d.length() > JOY_RADIUS: d = d.normalized()*JOY_RADIUS
			joy_now = joy_origin + d
			joy_vector = Vector2(d.x/JOY_RADIUS, d.y/JOY_RADIUS)
			hud.set_joystick(joy_origin, joy_now, true)
		elif event.index == look_finger:
			yaw -= event.relative.x * 0.008
			pitch = clamp(pitch - event.relative.y * 0.006, -0.72, 0.18)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		yaw -= event.relative.x * 0.006
		pitch = clamp(pitch - event.relative.y * 0.006, -0.72, 0.18)
