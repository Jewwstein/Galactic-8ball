extends Node2D

var body_style := 0
var palette := 0
var eye_style := 0
var marking_style := 0
var core_style := 0
var opacity := 0.82
var aura := 0.62
var t := 0.0

var palettes := [
	Color(0.18,0.78,1.0),
	Color(0.56,0.36,1.0),
	Color(0.98,0.38,0.24),
	Color(0.28,0.84,0.52),
	Color(0.88,0.93,1.0),
	Color(0.14,0.12,0.22)
]

func _process(delta):
	t += delta
	queue_redraw()

func set_config(cfg: Dictionary):
	body_style = int(cfg.get("body_style",0))
	palette = int(cfg.get("palette",0))
	eye_style = int(cfg.get("eye_style",0))
	marking_style = int(cfg.get("marking_style",0))
	core_style = int(cfg.get("core_style",0))
	opacity = float(cfg.get("opacity",0.82))
	aura = float(cfg.get("aura",0.62))
	queue_redraw()

func _draw():
	var c = palettes[clamp(palette,0,palettes.size()-1)]
	var center = Vector2(1024, 1034)
	var breathe = 1.0 + sin(t * 2.25) * 0.022
	var pts = body_points(body_style, breathe)

	# outer aura glow
	for i in range(7, 0, -1):
		var glow = pts.duplicate()
		var scale_amt = 1.0 + (i * 0.02 * aura)
		for j in glow.size():
			glow[j] = center + (glow[j] - center) * scale_amt
		draw_colored_polygon(glow, Color(c.r, c.g, c.b, 0.013 * i * max(aura, 0.08)))

	# ground shadow
	var shadow := PackedVector2Array()
	for p in pts:
		shadow.append(Vector2(p.x, p.y + 42))
	draw_colored_polygon(shadow, Color(0.0,0.0,0.0,0.22))

	# base body
	draw_colored_polygon(pts, Color(c.r, c.g, c.b, opacity))

	# anime-style cel shadow blocks
	var shadow_pts := PackedVector2Array()
	for p in pts:
		shadow_pts.append(center + (p - center) * 0.92 + Vector2(72, 58))
	draw_colored_polygon(shadow_pts, Color(c.darkened(0.42).r, c.darkened(0.42).g, c.darkened(0.42).b, 0.20))

	# soft inner gradient illusion
	var inner := PackedVector2Array()
	for p in pts:
		inner.append(center + (p - center) * 0.97 + Vector2(0, 18))
	draw_colored_polygon(inner, Color(c.lightened(0.05).r, c.lightened(0.05).g, c.lightened(0.05).b, 0.08))

	# large glossy anime highlights
	draw_ellipse(Vector2(782, 652), 288, 168, Color(1,1,1,0.23 * opacity), -0.34)
	draw_ellipse(Vector2(690, 768), 126, 72, Color(1,1,1,0.15 * opacity), -0.34)
	draw_ellipse(Vector2(1212, 1240), 98, 54, Color(1,1,1,0.05 * opacity), 0.24)

	draw_markings(c)
	draw_core(c)
	draw_eyes()
	draw_mouth()

func body_points(style: int, squish: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var center := Vector2(1024, 1034)
	var rx := 620.0
	var ry := 510.0 * squish
	if style == 1:
		rx = 525
		ry = 602 * squish
	elif style == 2:
		rx = 722
		ry = 438 * squish
	elif style == 3:
		rx = 640
		ry = 512 * squish
	for i in 144:
		var a = TAU * float(i) / 144.0
		var x = cos(a)
		var y = sin(a)
		var modx = 1.0
		var mody = 1.0
		if style == 1:
			modx = 0.74 + 0.26 * ((y + 1.0) * 0.5)
		elif style == 2:
			mody = 0.92 + 0.08 * cos(a * 2.0)
		elif style == 3:
			if y < -0.25:
				modx = 0.86 + 0.14 * cos(a * 3.0)
		var px = center.x + x * rx * modx
		var py = center.y + y * ry * mody
		if y > 0.55:
			py -= (y - 0.55) * 175.0
		pts.append(Vector2(px, py))
	return pts

func draw_ellipse(center: Vector2, rx: float, ry: float, color: Color, rot := 0.0):
	var pts := PackedVector2Array()
	for i in 72:
		var a = TAU * float(i) / 72.0
		pts.append(Vector2(cos(a) * rx, sin(a) * ry).rotated(rot) + center)
	draw_colored_polygon(pts, color)

func draw_core(body_color: Color):
	if core_style == 3:
		return
	var center = Vector2(1024, 1086)
	var pulse = 1.0 + sin(t * 3.0) * 0.055
	for i in range(5, 0, -1):
		draw_circle(center, 154.0 * pulse + i * 26.0 * max(aura, 0.08), Color(0.40, 0.96, 1.0, 0.016 * i * max(aura, 0.08)))
	if core_style == 0:
		draw_circle(center, 120 * pulse, Color(0.40, 0.97, 1.0, 0.70))
		draw_circle(center - Vector2(24, 32), 44 * pulse, Color(1,1,1,0.62))
	elif core_style == 1:
		draw_colored_polygon(star_points(center, 130 * pulse, 60 * pulse, 5), Color(0.96, 0.84, 0.34, 0.78))
	elif core_style == 2:
		draw_circle(center, 118 * pulse, Color(0.92, 0.94, 1.0, 0.76))
		draw_circle(center + Vector2(52, -10), 104 * pulse, Color(body_color.r, body_color.g, body_color.b, 0.90))

func star_points(center: Vector2, outer: float, inner: float, count: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in count * 2:
		var r = outer if i % 2 == 0 else inner
		var a = -PI / 2 + PI * float(i) / count
		pts.append(center + Vector2(cos(a), sin(a)) * r)
	return pts

func draw_eyes():
	var left = Vector2(842, 904)
	var right = Vector2(1206, 904)
	match eye_style:
		0:
			draw_ellipse(left, 92, 126, Color(0.03,0.04,0.08,0.97))
			draw_ellipse(right, 92, 126, Color(0.03,0.04,0.08,0.97))
			draw_circle(left - Vector2(20, 32), 28, Color(0.72, 0.97, 1.0, 0.92))
			draw_circle(right - Vector2(20, 32), 28, Color(0.72, 0.97, 1.0, 0.92))
		1:
			draw_colored_polygon(PackedVector2Array([left+Vector2(-110,-38), left+Vector2(98,-72), left+Vector2(74,84), left+Vector2(-82,92)]), Color(0.02,0.03,0.06,0.97))
			draw_colored_polygon(PackedVector2Array([right+Vector2(-98,-72), right+Vector2(110,-38), right+Vector2(82,92), right+Vector2(-74,84)]), Color(0.02,0.03,0.06,0.97))
		2:
			draw_circle(left, 106, Color(0.01,0.01,0.02,0.98))
			draw_circle(right, 106, Color(0.01,0.01,0.02,0.98))
			draw_circle(left, 42, Color(0.68,0.24,1.0,0.98))
			draw_circle(right, 42, Color(0.68,0.24,1.0,0.98))
		3:
			draw_colored_polygon(star_points(left, 106, 44, 5), Color(1.0,0.94,0.54,0.98))
			draw_colored_polygon(star_points(right, 106, 44, 5), Color(1.0,0.94,0.54,0.98))

func draw_mouth():
	var pts := PackedVector2Array()
	for i in 30:
		var a = PI * float(i) / 29.0
		pts.append(Vector2(1024 - 128 * cos(a), 1118 + 50 * sin(a)))
	draw_polyline(pts, Color(0.04, 0.04, 0.08, 0.78), 18.0, true)

func draw_markings(body_color: Color):
	if marking_style == 0:
		return
	var mc = Color(0.88, 0.98, 1.0, 0.36)
	if marking_style == 1:
		draw_arc(Vector2(1024, 812), 186, -2.5, -0.65, 40, mc, 18, true)
		draw_line(Vector2(1024, 650), Vector2(1024, 748), mc, 18, true)
		draw_circle(Vector2(1024, 620), 24, mc)
	elif marking_style == 2:
		for i in 16:
			var a = float(i) * 2.399
			var r = 120.0 + 28.0 * i
			var p = Vector2(1024, 960) + Vector2(cos(a), sin(a)) * min(r, 440.0)
			draw_circle(p, 16 + (i % 3) * 5, Color(1,1,1,0.20))
	elif marking_style == 3:
		draw_arc(Vector2(1024, 1040), 424, PI * 1.08, PI * 1.92, 72, mc, 28, true)
		draw_arc(Vector2(1024, 1040), 354, PI * 1.12, PI * 1.88, 72, Color(body_color.darkened(0.4).r, body_color.darkened(0.4).g, body_color.darkened(0.4).b, 0.26), 18, true)
