# Soul Slime Prototype

An original Android action-RPG prototype inspired by reincarnation/progression fantasy.

## Prototype loop

1. Receive a randomized modern-world death and affinity.
2. Choose one of three randomly offered reincarnation skills.
3. Customize slime body color, eye style, and glow.
4. Spawn in a crystal cave.
5. Move with the virtual joystick and collect mana crystals.
6. Fight cave creatures with **Strike**.
7. Devour defeated creatures with **Absorb** to analyze and acquire traits.
8. Accumulate Essence and Morph Data toward later evolution/human-form systems.

## Controls

- Left thumb: movement joystick.
- STRIKE: damage nearby enemy.
- ABSORB: devour a nearby defeated enemy.
- Tap the skill chip at top right to inspect the chosen skill.

This prototype intentionally uses original names, art drawn at runtime, and lore rather than copyrighted anime assets.
