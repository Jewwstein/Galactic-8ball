package com.soulslime.prototype;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        hideSystemUi();
        setContentView(new GameView());
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    private void hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private class GameView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rng = new Random();
        private Screen screen = Screen.DEATH;
        private DeathEvent death;
        private final List<Skill> offered = new ArrayList<>();
        private Skill chosenSkill;

        private final int[] slimeColors = {
                Color.rgb(85, 220, 245), Color.rgb(176, 103, 255), Color.rgb(255, 115, 182),
                Color.rgb(96, 235, 148), Color.rgb(255, 191, 82), Color.rgb(205, 224, 255)
        };
        private int slimeColorIndex = 0;
        private int eyeStyle = 0;
        private boolean glow = true;

        private final Player player = new Player();
        private final List<Crystal> crystals = new ArrayList<>();
        private final List<Enemy> enemies = new ArrayList<>();
        private final List<String> acquiredTraits = new ArrayList<>();
        private int essence = 0;
        private int morphData = 0;
        private int level = 1;
        private int xp = 0;
        private long lastFrame = System.nanoTime();
        private long messageUntil = 0;
        private String message = "";
        private long attackReadyAt = 0;

        private int joystickPointer = -1;
        private float joyCenterX, joyCenterY, joyX, joyY;
        private float moveX = 0f, moveY = 0f;
        private final RectF strikeRect = new RectF();
        private final RectF absorbRect = new RectF();
        private final RectF skillChipRect = new RectF();

        private final DeathEvent[] deaths = {
                new DeathEvent("Last-Minute Rescue", "You pushed a stranger out of danger. Your final thought was simple: protect them.", "Guardian", Color.rgb(112, 205, 255)),
                new DeathEvent("Winter Breakdown", "A vehicle failed during a brutal cold snap. You endured until your body could no longer keep its warmth.", "Frost", Color.rgb(151, 224, 255)),
                new DeathEvent("Floodwater", "A sudden surge swept you away. In the final seconds, every instinct focused on adapting and reaching air.", "Water", Color.rgb(73, 146, 255)),
                new DeathEvent("Electrical Surge", "A freak power fault struck without warning. Your senses seemed to accelerate in the instant before everything went dark.", "Storm", Color.rgb(190, 135, 255)),
                new DeathEvent("Warehouse Collapse", "You were trapped beneath falling debris. Even then, you kept searching for a way through.", "Stone", Color.rgb(191, 169, 137)),
                new DeathEvent("Smoke and Flame", "You went back inside to help someone escape a fire. Heat swallowed the room, but your resolve held.", "Flame", Color.rgb(255, 119, 72))
        };

        private final Skill[] skillPool = {
                new Skill("Adaptive Body", "Taking elemental damage gradually builds resistance to that element.", "SURVIVAL"),
                new Skill("Essence Hunger", "Absorbing crystals grants 25% more Essence.", "DEVOUR"),
                new Skill("Quick Thought", "Shortens combat cooldowns and later improves analysis speed.", "MIND"),
                new Skill("Predator Instinct", "Deal extra damage to wounded creatures and gain more Morph Data from them.", "DEVOUR"),
                new Skill("Guardian Pulse", "Taking a heavy hit briefly hardens your slime body.", "SURVIVAL"),
                new Skill("Arcane Sense", "Nearby crystals pulse through walls and rare resources become easier to detect.", "MAGIC"),
                new Skill("Rapid Regeneration", "Recover slowly after avoiding damage for several seconds.", "SURVIVAL"),
                new Skill("Mimic Seed", "Gain extra Morph Data when analyzing living creatures.", "MORPH"),
                new Skill("Mana Thread", "Future spells cost less mana and chaining elements becomes easier.", "MAGIC")
        };

        GameView() {
            super(MainActivity.this);
            setFocusable(true);
            setKeepScreenOn(true);
            rollNewLife();
        }

        private void rollNewLife() {
            death = deaths[rng.nextInt(deaths.length)];
            offered.clear();
            List<Skill> bag = new ArrayList<>();
            Collections.addAll(bag, skillPool);
            Collections.shuffle(bag, rng);
            for (int i = 0; i < 3; i++) offered.add(bag.get(i));
            chosenSkill = null;
            screen = Screen.DEATH;
            acquiredTraits.clear();
            essence = 0;
            morphData = 0;
            level = 1;
            xp = 0;
        }

        private void beginCave() {
            screen = Screen.GAME;
            player.x = 1000;
            player.y = 600;
            player.hp = 100;
            crystals.clear();
            enemies.clear();
            for (int i = 0; i < 26; i++) {
                float x = 130 + rng.nextFloat() * 1740;
                float y = 110 + rng.nextFloat() * 980;
                crystals.add(new Crystal(x, y, 14 + rng.nextFloat() * 10));
            }
            enemies.add(new Enemy(520, 330, "Cave Fang", "Keen Scent"));
            enemies.add(new Enemy(1530, 360, "Moss Crawler", "Acid Skin"));
            enemies.add(new Enemy(1640, 850, "Echo Bat", "Night Sense"));
            enemies.add(new Enemy(470, 920, "Crystal Beetle", "Harden Shell"));
            flash("Awakening complete. Collect crystals and survive.", 3000);
            lastFrame = System.nanoTime();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (screen == Screen.GAME) {
                long now = System.nanoTime();
                float dt = Math.min(0.035f, (now - lastFrame) / 1_000_000_000f);
                lastFrame = now;
                updateGame(dt);
                drawGame(c);
                postInvalidateOnAnimation();
            } else if (screen == Screen.DEATH) drawDeath(c);
            else if (screen == Screen.SKILL) drawSkillChoice(c);
            else drawCustomize(c);
        }

        private void drawBackground(Canvas c, int top, int bottom) {
            p.setColor(top);
            c.drawColor(top);
            p.setColor(bottom);
            c.drawRect(0, getHeight() * .58f, getWidth(), getHeight(), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f);
            p.setColor(Color.argb(36, 190, 226, 255));
            for (int i = -getHeight(); i < getWidth() + getHeight(); i += 56) {
                c.drawLine(i, 0, i + getHeight(), getHeight(), p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void drawDeath(Canvas c) {
            int w = getWidth(), h = getHeight();
            drawBackground(c, Color.rgb(7, 10, 22), Color.rgb(13, 18, 38));
            text(c, "SOUL SLIME", w * .07f, h * .13f, Math.min(46, h * .075f), Color.WHITE, Paint.Align.LEFT, true);
            text(c, "FIRST AWAKENING • PROTOTYPE", w * .07f, h * .19f, Math.min(19, h * .032f), Color.rgb(139, 184, 216), Paint.Align.LEFT, false);

            RectF card = new RectF(w * .07f, h * .28f, w * .72f, h * .77f);
            panel(c, card, Color.argb(230, 17, 24, 46), Color.argb(150, 120, 210, 255));
            text(c, "YOUR LAST MOMENT", card.left + 28, card.top + 48, 19, Color.rgb(137, 191, 225), Paint.Align.LEFT, true);
            text(c, death.title, card.left + 28, card.top + 100, 34, Color.WHITE, Paint.Align.LEFT, true);
            wrap(c, death.text, card.left + 28, card.top + 145, card.width() - 56, 23, 34, Color.rgb(215, 225, 238));
            text(c, "SOUL AFFINITY", card.left + 28, card.bottom - 80, 16, Color.rgb(139, 184, 216), Paint.Align.LEFT, true);
            text(c, death.affinity.toUpperCase(Locale.US), card.left + 28, card.bottom - 42, 25, death.color, Paint.Align.LEFT, true);

            RectF btn = new RectF(w * .76f, h * .56f, w * .94f, h * .72f);
            button(c, btn, "REINCARNATE", death.color);
            wrap(c, "A new body waits somewhere beyond this life.", w * .76f, h * .79f, w * .18f, 16, 24, Color.rgb(151, 170, 190));
        }

        private void drawSkillChoice(Canvas c) {
            int w = getWidth(), h = getHeight();
            drawBackground(c, Color.rgb(8, 12, 25), Color.rgb(12, 21, 36));
            text(c, "CHOOSE A REINCARNATION GIFT", w * .5f, h * .11f, 30, Color.WHITE, Paint.Align.CENTER, true);
            text(c, "Your " + death.affinity + " affinity has shaped the available possibilities.", w * .5f, h * .17f, 17, Color.rgb(154, 184, 207), Paint.Align.CENTER, false);

            float gap = w * .025f;
            float left = w * .06f;
            float cardW = (w * .88f - gap * 2) / 3f;
            for (int i = 0; i < offered.size(); i++) {
                Skill s = offered.get(i);
                RectF r = new RectF(left + i * (cardW + gap), h * .27f, left + i * (cardW + gap) + cardW, h * .78f);
                panel(c, r, Color.argb(235, 18, 28, 48), Color.argb(160, 103, 208, 255));
                text(c, s.type, r.centerX(), r.top + 43, 14, Color.rgb(123, 196, 234), Paint.Align.CENTER, true);
                text(c, s.name, r.centerX(), r.top + 91, 25, Color.WHITE, Paint.Align.CENTER, true);
                wrap(c, s.description, r.left + 24, r.top + 135, r.width() - 48, 18, 28, Color.rgb(208, 221, 235));
                RectF choose = new RectF(r.left + 22, r.bottom - 72, r.right - 22, r.bottom - 22);
                button(c, choose, "CHOOSE", death.color);
            }
        }

        private void drawCustomize(Canvas c) {
            int w = getWidth(), h = getHeight();
            drawBackground(c, Color.rgb(7, 13, 24), Color.rgb(12, 28, 39));
            text(c, "SHAPE YOUR NEW BODY", w * .5f, h * .1f, 30, Color.WHITE, Paint.Align.CENTER, true);
            text(c, "This slime form remains yours even after later transformations.", w * .5f, h * .155f, 16, Color.rgb(154, 184, 207), Paint.Align.CENTER, false);

            RectF preview = new RectF(w * .08f, h * .24f, w * .43f, h * .8f);
            panel(c, preview, Color.argb(235, 13, 22, 38), Color.argb(120, 102, 230, 255));
            drawSlime(c, preview.centerX(), preview.centerY() + 15, Math.min(preview.width(), preview.height()) * .24f, slimeColors[slimeColorIndex], eyeStyle, glow);
            text(c, chosenSkill.name, preview.centerX(), preview.bottom - 45, 18, death.color, Paint.Align.CENTER, true);

            float x1 = w * .52f, x2 = w * .9f;
            optionRow(c, "BODY COLOR", x1, h * .29f, x2, slimeColorName());
            optionRow(c, "EYES", x1, h * .44f, x2, eyeName());
            RectF glowBtn = new RectF(x1, h * .55f, x2, h * .64f);
            button(c, glowBtn, glow ? "AURA GLOW: ON" : "AURA GLOW: OFF", glow ? slimeColors[slimeColorIndex] : Color.rgb(90, 105, 125));
            RectF start = new RectF(x1, h * .7f, x2, h * .81f);
            button(c, start, "AWAKEN IN THE CAVE", death.color);
        }

        private void optionRow(Canvas c, String label, float left, float top, float right, String value) {
            text(c, label, left, top, 15, Color.rgb(130, 172, 204), Paint.Align.LEFT, true);
            RectF prev = new RectF(left, top + 18, left + 58, top + 77);
            RectF next = new RectF(right - 58, top + 18, right, top + 77);
            button(c, prev, "‹", Color.rgb(75, 112, 145));
            button(c, next, "›", Color.rgb(75, 112, 145));
            text(c, value, (prev.right + next.left) / 2, top + 57, 22, Color.WHITE, Paint.Align.CENTER, true);
        }

        private void updateGame(float dt) {
            float speed = 310f;
            player.x += moveX * speed * dt;
            player.y += moveY * speed * dt;
            player.x = clamp(player.x, 70, 1930);
            player.y = clamp(player.y, 70, 1130);

            for (Crystal crystal : crystals) {
                if (!crystal.collected && dist(player.x, player.y, crystal.x, crystal.y) < 58) {
                    crystal.collected = true;
                    int gain = chosenSkill != null && chosenSkill.name.equals("Essence Hunger") ? 2 : 1;
                    essence += gain;
                    xp += 8;
                    if (essence % 5 == 0) flash("Analysis: Essence threshold reached. New skill paths detected.", 2200);
                    checkLevel();
                }
            }

            for (Enemy e : enemies) {
                if (e.absorbed || e.dead) continue;
                float d = dist(player.x, player.y, e.x, e.y);
                if (d < 460 && d > 82) {
                    float dx = (player.x - e.x) / Math.max(1f, d);
                    float dy = (player.y - e.y) / Math.max(1f, d);
                    e.x += dx * e.speed * dt;
                    e.y += dy * e.speed * dt;
                }
                if (d < 86) {
                    e.hitTimer -= dt;
                    if (e.hitTimer <= 0) {
                        player.hp -= 7;
                        e.hitTimer = 0.85f;
                        flash(e.name + " strikes you!", 900);
                        if (player.hp <= 0) {
                            player.hp = 100;
                            player.x = 1000;
                            player.y = 600;
                            flash("Soul Core restored your prototype body at the awakening point.", 2500);
                        }
                    }
                }
            }
        }

        private void checkLevel() {
            int need = level * 40;
            if (xp >= need) {
                xp -= need;
                level++;
                flash("LEVEL " + level + " — your core grows denser.", 2000);
            }
        }

        private void doStrike() {
            long now = System.currentTimeMillis();
            long cooldown = chosenSkill != null && chosenSkill.name.equals("Quick Thought") ? 350 : 500;
            if (now < attackReadyAt) return;
            attackReadyAt = now + cooldown;
            Enemy target = nearestEnemy(false, 190);
            if (target == null) {
                flash("No hostile creature in range.", 700);
                return;
            }
            int dmg = target.hp <= 50 && chosenSkill != null && chosenSkill.name.equals("Predator Instinct") ? 52 : 36;
            target.hp -= dmg;
            if (target.hp <= 0) {
                target.hp = 0;
                target.dead = true;
                xp += 20;
                checkLevel();
                flash(target.name + " defeated. Move close and ABSORB to analyze it.", 2200);
            } else {
                flash("Strike: " + dmg + " damage", 650);
            }
        }

        private void doAbsorb() {
            Enemy target = nearestEnemy(true, 175);
            if (target == null) {
                flash("Nothing defeated is close enough to absorb.", 800);
                return;
            }
            target.absorbed = true;
            int morphGain = 25;
            if (chosenSkill != null && (chosenSkill.name.equals("Mimic Seed") || chosenSkill.name.equals("Predator Instinct"))) morphGain += 10;
            morphData = Math.min(100, morphData + morphGain);
            essence += 3;
            if (!acquiredTraits.contains(target.trait)) acquiredTraits.add(target.trait);
            flash("Analysis complete: acquired trait — " + target.trait + ".", 2500);
        }

        private Enemy nearestEnemy(boolean deadOnly, float maxDist) {
            Enemy best = null;
            float bd = maxDist;
            for (Enemy e : enemies) {
                if (e.absorbed) continue;
                if (deadOnly && !e.dead) continue;
                if (!deadOnly && e.dead) continue;
                float d = dist(player.x, player.y, e.x, e.y);
                if (d < bd) { bd = d; best = e; }
            }
            return best;
        }

        private void drawGame(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(Color.rgb(5, 9, 16));

            float camX = clamp(player.x, w * .5f, 2000 - w * .5f);
            float camY = clamp(player.y, h * .5f, 1200 - h * .5f);
            float ox = w * .5f - camX;
            float oy = h * .5f - camY;

            p.setColor(Color.rgb(18, 24, 31));
            c.drawRoundRect(new RectF(ox + 25, oy + 25, ox + 1975, oy + 1175), 80, 80, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(8);
            p.setColor(Color.rgb(43, 55, 67));
            c.drawRoundRect(new RectF(ox + 35, oy + 35, ox + 1965, oy + 1165), 72, 72, p);
            p.setStyle(Paint.Style.FILL);

            // cave veins and ambient crystal shards
            p.setStrokeWidth(3);
            p.setColor(Color.argb(55, 96, 159, 193));
            for (int i = 0; i < 14; i++) {
                float y = oy + 90 + i * 78;
                c.drawLine(ox + 90, y, ox + 280 + (i % 3) * 60, y + 22, p);
                c.drawLine(ox + 1710 - (i % 4) * 35, y + 20, ox + 1910, y - 10, p);
            }

            for (Crystal cr : crystals) if (!cr.collected) drawCrystal(c, ox + cr.x, oy + cr.y, cr.r);
            for (Enemy e : enemies) if (!e.absorbed) drawEnemy(c, ox + e.x, oy + e.y, e);
            drawSlime(c, ox + player.x, oy + player.y, 42, slimeColors[slimeColorIndex], eyeStyle, glow);

            drawHud(c);
        }

        private void drawHud(Canvas c) {
            int w = getWidth(), h = getHeight();
            RectF top = new RectF(18, 16, w - 18, 94);
            panel(c, top, Color.argb(215, 8, 14, 25), Color.argb(90, 113, 203, 238));
            text(c, "LV " + level, 38, 48, 17, Color.WHITE, Paint.Align.LEFT, true);
            drawBar(c, 38, 60, 165, 12, player.hp / 100f, Color.rgb(102, 236, 162));
            text(c, "ESSENCE " + essence, 230, 49, 17, Color.rgb(121, 222, 255), Paint.Align.LEFT, true);
            text(c, "MORPH " + morphData + "%", 360, 49, 17, Color.rgb(210, 141, 255), Paint.Align.LEFT, true);
            drawBar(c, 360, 60, 165, 12, morphData / 100f, Color.rgb(196, 111, 255));

            skillChipRect.set(w - 270, 30, w - 38, 78);
            panel(c, skillChipRect, Color.argb(230, 27, 35, 53), death.color);
            text(c, chosenSkill.name, skillChipRect.centerX(), skillChipRect.centerY() + 6, 15, Color.WHITE, Paint.Align.CENTER, true);

            float base = Math.min(w, h) * .14f;
            joyCenterX = 42 + base;
            joyCenterY = h - 38 - base;
            float jr = base * .72f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 125, 175, 205));
            c.drawCircle(joyCenterX, joyCenterY, jr, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3);
            p.setColor(Color.argb(145, 159, 218, 246));
            c.drawCircle(joyCenterX, joyCenterY, jr, p);
            p.setStyle(Paint.Style.FILL);
            float knobX = joyCenterX + moveX * jr * .62f;
            float knobY = joyCenterY + moveY * jr * .62f;
            p.setColor(Color.argb(195, 165, 226, 249));
            c.drawCircle(knobX, knobY, jr * .36f, p);

            float bw = Math.min(170, w * .14f);
            float bh = Math.min(82, h * .15f);
            strikeRect.set(w - bw - 42, h - bh - 40, w - 42, h - 40);
            absorbRect.set(w - bw * 2 - 62, h - bh - 40, w - bw - 62, h - 40);
            button(c, absorbRect, "ABSORB", Color.rgb(137, 93, 219));
            button(c, strikeRect, "STRIKE", Color.rgb(57, 147, 205));

            if (!acquiredTraits.isEmpty()) {
                String latest = acquiredTraits.get(acquiredTraits.size() - 1);
                text(c, "Latest trait: " + latest, w * .5f, h - 32, 14, Color.rgb(179, 195, 210), Paint.Align.CENTER, false);
            }

            if (morphData >= 100) {
                RectF unlocked = new RectF(w * .37f, 108, w * .63f, 153);
                panel(c, unlocked, Color.argb(235, 44, 23, 67), Color.rgb(208, 139, 255));
                text(c, "MIMIC FORM UNLOCKED • prototype milestone", unlocked.centerX(), unlocked.centerY() + 5, 14, Color.WHITE, Paint.Align.CENTER, true);
            }

            if (System.currentTimeMillis() < messageUntil) {
                RectF msg = new RectF(w * .23f, h * .75f, w * .77f, h * .86f);
                panel(c, msg, Color.argb(225, 7, 12, 22), Color.argb(100, 133, 213, 245));
                text(c, message, msg.centerX(), msg.centerY() + 6, 15, Color.WHITE, Paint.Align.CENTER, true);
            }
        }

        private void drawEnemy(Canvas c, float x, float y, Enemy e) {
            int base = e.dead ? Color.rgb(77, 83, 91) : Color.rgb(178, 70, 87);
            p.setColor(base);
            c.drawOval(new RectF(x - 34, y - 25, x + 34, y + 25), p);
            if (!e.dead) {
                p.setColor(Color.rgb(245, 214, 166));
                c.drawCircle(x - 11, y - 3, 4, p);
                c.drawCircle(x + 11, y - 3, 4, p);
            }
            text(c, e.dead ? "DOWNED" : e.name, x, y - 39, 12, e.dead ? Color.rgb(185, 191, 198) : Color.rgb(240, 204, 211), Paint.Align.CENTER, true);
            if (!e.dead) drawBar(c, x - 35, y + 34, 70, 7, e.hp / 100f, Color.rgb(238, 92, 104));
        }

        private void drawCrystal(Canvas c, float x, float y, float r) {
            if (glow) {
                p.setColor(Color.argb(35, 102, 221, 255));
                c.drawCircle(x, y, r * 2.1f, p);
            }
            Path path = new Path();
            path.moveTo(x, y - r * 1.45f);
            path.lineTo(x + r * .78f, y - r * .2f);
            path.lineTo(x + r * .45f, y + r * 1.15f);
            path.lineTo(x - r * .5f, y + r * 1.15f);
            path.lineTo(x - r * .8f, y - r * .18f);
            path.close();
            p.setColor(Color.rgb(102, 213, 255));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            p.setColor(Color.rgb(210, 248, 255));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSlime(Canvas c, float x, float y, float r, int color, int eyes, boolean aura) {
            if (aura) {
                p.setColor(withAlpha(color, 45));
                c.drawCircle(x, y + 2, r * 1.35f, p);
            }
            p.setColor(withAlpha(color, 225));
            RectF body = new RectF(x - r, y - r * .8f, x + r, y + r * .9f);
            c.drawOval(body, p);
            p.setColor(withAlpha(Color.WHITE, 75));
            c.drawOval(new RectF(x - r * .55f, y - r * .48f, x - r * .02f, y - r * .15f), p);
            p.setColor(Color.rgb(17, 29, 39));
            if (eyes == 0) {
                c.drawCircle(x - r * .27f, y - r * .05f, r * .075f, p);
                c.drawCircle(x + r * .27f, y - r * .05f, r * .075f, p);
            } else if (eyes == 1) {
                p.setStrokeWidth(Math.max(2, r * .06f));
                c.drawLine(x - r * .38f, y - r * .10f, x - r * .13f, y - r * .02f, p);
                c.drawLine(x + r * .38f, y - r * .10f, x + r * .13f, y - r * .02f, p);
            } else {
                c.drawOval(new RectF(x - r * .42f, y - r * .19f, x - r * .12f, y + r * .02f), p);
                c.drawOval(new RectF(x + r * .12f, y - r * .19f, x + r * .42f, y + r * .02f), p);
            }
        }

        private void drawBar(Canvas c, float x, float y, float width, float height, float value, int color) {
            p.setColor(Color.argb(150, 47, 56, 69));
            c.drawRoundRect(new RectF(x, y, x + width, y + height), height / 2, height / 2, p);
            p.setColor(color);
            c.drawRoundRect(new RectF(x, y, x + width * clamp(value, 0f, 1f), y + height), height / 2, height / 2, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (screen != Screen.GAME) return handleMenuTouch(e);
            int action = e.getActionMasked();
            int idx = e.getActionIndex();
            int pid = e.getPointerId(idx);
            float x = e.getX(idx), y = e.getY(idx);

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                if (x < getWidth() * .36f && y > getHeight() * .52f && joystickPointer == -1) {
                    joystickPointer = pid;
                    updateJoystick(x, y);
                } else if (strikeRect.contains(x, y)) {
                    doStrike();
                } else if (absorbRect.contains(x, y)) {
                    doAbsorb();
                } else if (skillChipRect.contains(x, y)) {
                    flash(chosenSkill.name + ": " + chosenSkill.description, 2800);
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                if (joystickPointer != -1) {
                    int j = e.findPointerIndex(joystickPointer);
                    if (j >= 0) updateJoystick(e.getX(j), e.getY(j));
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pid == joystickPointer || action == MotionEvent.ACTION_CANCEL) {
                    joystickPointer = -1;
                    moveX = moveY = 0f;
                }
            }
            return true;
        }

        private boolean handleMenuTouch(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            int w = getWidth(), h = getHeight();
            if (screen == Screen.DEATH) {
                if (x > w * .73f && y > h * .5f) { screen = Screen.SKILL; invalidate(); }
            } else if (screen == Screen.SKILL) {
                float gap = w * .025f, left = w * .06f;
                float cardW = (w * .88f - gap * 2) / 3f;
                for (int i = 0; i < 3; i++) {
                    RectF r = new RectF(left + i * (cardW + gap), h * .27f, left + i * (cardW + gap) + cardW, h * .78f);
                    if (r.contains(x, y)) {
                        chosenSkill = offered.get(i);
                        screen = Screen.CUSTOMIZE;
                        invalidate();
                        break;
                    }
                }
            } else if (screen == Screen.CUSTOMIZE) {
                float l = w * .52f, r = w * .9f;
                if (y > h * .29f + 18 && y < h * .29f + 77) {
                    if (x < l + 75) slimeColorIndex = (slimeColorIndex + slimeColors.length - 1) % slimeColors.length;
                    else if (x > r - 75) slimeColorIndex = (slimeColorIndex + 1) % slimeColors.length;
                } else if (y > h * .44f + 18 && y < h * .44f + 77) {
                    if (x < l + 75) eyeStyle = (eyeStyle + 2) % 3;
                    else if (x > r - 75) eyeStyle = (eyeStyle + 1) % 3;
                } else if (x > l && x < r && y > h * .55f && y < h * .64f) {
                    glow = !glow;
                } else if (x > l && x < r && y > h * .69f && y < h * .83f) {
                    beginCave();
                }
                invalidate();
            }
            return true;
        }

        private void updateJoystick(float x, float y) {
            float dx = x - joyCenterX;
            float dy = y - joyCenterY;
            float max = Math.min(getWidth(), getHeight()) * .105f;
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len > max) { dx = dx / len * max; dy = dy / len * max; }
            moveX = dx / max;
            moveY = dy / max;
            joyX = x; joyY = y;
        }

        private void panel(Canvas c, RectF r, int fill, int stroke) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            c.drawRoundRect(r, 18, 18, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            p.setColor(stroke);
            c.drawRoundRect(r, 18, 18, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void button(Canvas c, RectF r, String label, int accent) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(withAlpha(accent, 65));
            c.drawRoundRect(r, 14, 14, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.5f);
            p.setColor(accent);
            c.drawRoundRect(r, 14, 14, p);
            p.setStyle(Paint.Style.FILL);
            float size = Math.min(18, r.height() * .32f);
            text(c, label, r.centerX(), r.centerY() + size * .36f, size, Color.WHITE, Paint.Align.CENTER, true);
        }

        private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
            p.setColor(color);
            p.setTextSize(size);
            p.setTextAlign(align);
            p.setTypeface(bold ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            p.setStyle(Paint.Style.FILL);
            c.drawText(s, x, y, p);
        }

        private void wrap(Canvas c, String s, float x, float y, float maxW, float size, float lineH, int color) {
            p.setTextSize(size);
            p.setTypeface(android.graphics.Typeface.DEFAULT);
            p.setTextAlign(Paint.Align.LEFT);
            p.setColor(color);
            String[] words = s.split(" ");
            StringBuilder line = new StringBuilder();
            float yy = y;
            for (String word : words) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (p.measureText(test) > maxW && line.length() > 0) {
                    c.drawText(line.toString(), x, yy, p);
                    yy += lineH;
                    line = new StringBuilder(word);
                } else line = new StringBuilder(test);
            }
            if (line.length() > 0) c.drawText(line.toString(), x, yy, p);
        }

        private void flash(String s, int ms) {
            message = s;
            messageUntil = System.currentTimeMillis() + ms;
        }

        private String slimeColorName() {
            String[] names = {"AQUA", "AMETHYST", "ROSE", "VERDANT", "AMBER", "MOONGLASS"};
            return names[slimeColorIndex];
        }

        private String eyeName() {
            return eyeStyle == 0 ? "CALM" : eyeStyle == 1 ? "SHARP" : "ARCANE";
        }

        private int withAlpha(int color, int alpha) {
            return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
        }

        private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
        private float dist(float x1, float y1, float x2, float y2) {
            float dx = x2 - x1, dy = y2 - y1;
            return (float)Math.sqrt(dx * dx + dy * dy);
        }
    }

    private enum Screen { DEATH, SKILL, CUSTOMIZE, GAME }

    private static class DeathEvent {
        final String title, text, affinity;
        final int color;
        DeathEvent(String title, String text, String affinity, int color) {
            this.title = title; this.text = text; this.affinity = affinity; this.color = color;
        }
    }

    private static class Skill {
        final String name, description, type;
        Skill(String name, String description, String type) {
            this.name = name; this.description = description; this.type = type;
        }
    }

    private static class Player {
        float x, y;
        int hp = 100;
    }

    private static class Crystal {
        final float x, y, r;
        boolean collected = false;
        Crystal(float x, float y, float r) { this.x = x; this.y = y; this.r = r; }
    }

    private static class Enemy {
        float x, y;
        final String name, trait;
        int hp = 100;
        boolean dead = false, absorbed = false;
        float speed = 88f;
        float hitTimer = 0.2f;
        Enemy(float x, float y, String name, String trait) {
            this.x = x; this.y = y; this.name = name; this.trait = trait;
        }
    }
}
